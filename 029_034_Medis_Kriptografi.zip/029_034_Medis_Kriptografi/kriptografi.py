import os
import base64
import struct
import bcrypt
import hashlib
from Crypto.Cipher import AES, Blowfish
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
from PIL import Image

def derive_key(passphrase: str, length: int = 32) -> bytes:
    """
    Derive cryptographic key from user passphrase using PBKDF2-HMAC-SHA256.
    Default length = 32 bytes (for AES-256).
    """
    return hashlib.pbkdf2_hmac(
        'sha256',
        passphrase.encode(),
        salt=b"medisapp",  
        iterations=100_000
    )[:length]

def hash_password(password: str) -> bytes:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt())

def check_password(password: str, hashed: bytes) -> bool:
    return bcrypt.checkpw(password.encode(), hashed)

def aes_encrypt(data: bytes, passphrase: str) -> bytes:
    key = derive_key(passphrase, 32)
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct = cipher.encrypt(pad(data, AES.block_size))
    return base64.b64encode(iv + ct)

def aes_decrypt(enc_data: bytes, passphrase: str) -> bytes:
    key = derive_key(passphrase, 32)
    raw = base64.b64decode(enc_data)
    iv, ct = raw[:16], raw[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(ct), AES.block_size)

def caesar_encrypt(text, shift):
    result = ''
    for char in text:
        if char.isalpha():
            base = 'A' if char.isupper() else 'a'
            result += chr((ord(char) - ord(base) + shift) % 26 + ord(base))
        else:
            result += char
    return result

def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

def affine_encrypt(text, a, b):
    result = ''
    for char in text:
        if char.isalpha():
            base = 'A' if char.isupper() else 'a'
            result += chr(((a * (ord(char) - ord(base)) + b) % 26) + ord(base))
        else:
            result += char
    return result

def affine_decrypt(text, a, b):
    result = ''
    for i in range(26):
        if (a * i) % 26 == 1:
            inv_a = i
            break
    else:
        raise ValueError("a tidak relatif prima dengan 26")
    for char in text:
        if char.isalpha():
            base = 'A' if char.isupper() else 'a'
            result += chr((inv_a * ((ord(char) - ord(base)) - b)) % 26 + ord(base))
        else:
            result += char
    return result

def super_encrypt(text, passphrase, caesar_key, a_key, b_key):
    c1 = caesar_encrypt(text, caesar_key)
    c2 = affine_encrypt(c1, a_key, b_key)

    key = passphrase.encode()
    key = key.ljust(32, b'\0')[:32]  

    iv = get_random_bytes(16)  
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct = cipher.encrypt(pad(c2.encode(), AES.block_size))

    return base64.b64encode(iv + ct).decode()

def super_decrypt(cipher_b64, passphrase, caesar_key, a_key, b_key):
    key = passphrase.encode()
    key = key.ljust(32, b'\0')[:32]

    raw = base64.b64decode(cipher_b64)
    iv = raw[:16]      
    ct = raw[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = unpad(cipher.decrypt(ct), AES.block_size).decode()

    t2 = affine_decrypt(decrypted, a_key, b_key)
    t3 = caesar_decrypt(t2, caesar_key)
    return t3

def blowfish_encrypt_file(input_path, output_path, passphrase):
    """
    Enkripsi seluruh isi file menggunakan Blowfish (CBC mode)
    Hasil disimpan di path output dengan format file asli (tetap).
    """
    key = passphrase.encode("utf-8")
    cipher = Blowfish.new(key, Blowfish.MODE_CBC)
    bs = Blowfish.block_size
    iv = cipher.iv  

    with open(input_path, "rb") as f_in:
        data = f_in.read()

    ct_bytes = cipher.encrypt(pad(data, bs))
    encrypted_data = iv + ct_bytes

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "wb") as f_out:
        f_out.write(encrypted_data)

    return True

def blowfish_decrypt_file(input_path, output_path, passphrase):
    """
    Dekripsi file terenkripsi Blowfish, hasil disimpan ke path output (format asli tetap).
    """
    key = passphrase.encode("utf-8")
    bs = Blowfish.block_size

    with open(input_path, "rb") as f_in:
        data = f_in.read()

    iv = data[:bs]
    ct = data[bs:]

    cipher = Blowfish.new(key, Blowfish.MODE_CBC, iv)

    try:
        pt = unpad(cipher.decrypt(ct), bs)
    except ValueError:
        raise ValueError("Kunci Blowfish salah atau file rusak.")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "wb") as f_out:
        f_out.write(pt)

    return True

def rc4_ksa(key: bytes):
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key[i % len(key)]) & 0xFF
        S[i], S[j] = S[j], S[i]
    return S

def rc4_prga(S):
    i = j = 0
    while True:
        i = (i + 1) & 0xFF
        j = (j + S[i]) & 0xFF
        S[i], S[j] = S[j], S[i]
        yield S[(S[i] + S[j]) & 0xFF]

def rc4_encrypt(data: bytes, passphrase: str) -> bytes:
    key = derive_key(passphrase, 16)
    S = rc4_ksa(key)
    keystream = rc4_prga(S)
    return bytes([b ^ next(keystream) for b in data])

def _int_to_32bits(n: int) -> bytes:
    return struct.pack(">I", n)

def _32bits_to_int(b: bytes) -> int:
    return struct.unpack(">I", b)[0]

def stego_encode_image(input_path: str, output_path: str, message_bytes: bytes, passphrase: str) -> None:
    encrypted_msg = rc4_encrypt(message_bytes, passphrase)
    payload = _int_to_32bits(len(encrypted_msg)) + encrypted_msg

    img = Image.open(input_path)
    img = img.convert("RGB")
    width, height = img.size
    max_bits = width * height * 3

    if len(payload) * 8 > max_bits:
        raise ValueError("Pesan terlalu besar untuk disisipkan pada gambar ini.")

    pixels = list(img.getdata())
    flat_bits = []
    for byte in payload:
        for i in range(8):
            flat_bits.append((byte >> (7 - i)) & 1)

    new_pixels = []
    bit_idx = 0
    for pix in pixels:
        r, g, b = pix
        if bit_idx < len(flat_bits):
            r = (r & ~1) | flat_bits[bit_idx]; bit_idx += 1
        if bit_idx < len(flat_bits):
            g = (g & ~1) | flat_bits[bit_idx]; bit_idx += 1
        if bit_idx < len(flat_bits):
            b = (b & ~1) | flat_bits[bit_idx]; bit_idx += 1
        new_pixels.append((r, g, b))

    out_img = Image.new("RGB", (width, height))
    out_img.putdata(new_pixels)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    ext = os.path.splitext(input_path)[1]
    out_img.save(output_path.replace(".png", ext), format=ext.replace('.', '').upper())

def stego_decode_image(input_path: str, passphrase: str) -> bytes:
    img = Image.open(input_path)
    img = img.convert("RGB")
    pixels = list(img.getdata())

    bits = []
    for r, g, b in pixels:
        bits.append(r & 1)
        bits.append(g & 1)
        bits.append(b & 1)

    len_bits = bits[:32]
    lbytes = 0
    for bit in len_bits:
        lbytes = (lbytes << 1) | bit
    total_bits = (4 + lbytes) * 8
    payload_bits = bits[:total_bits]

    payload = bytearray()
    for i in range(0, total_bits, 8):
        byte = 0
        for b in payload_bits[i:i + 8]:
            byte = (byte << 1) | b
        payload.append(byte)

    enc_msg = bytes(payload[4:])
    decrypted = rc4_encrypt(enc_msg, passphrase)
    return decrypted



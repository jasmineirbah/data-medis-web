import os
import base64
import streamlit as st
from pathlib import Path
import datetime

def require_login():
    if "logged_in" not in st.session_state or not st.session_state["logged_in"]:
        st.warning("⚠️ Silakan login dulu di halaman Home.")
        st.stop()

from database import (
    create_user,
    authenticate_user,
    add_pasien,
    list_pasien,
    insert_history,
    get_history,
    ensure_patient_folders,
    make_output_filename,
)

try:
    import kriptografi
    KRYPTO_AVAILABLE = True
except Exception as e:
    KRYPTO_AVAILABLE = False
    _IMPORT_ERROR_STR = str(e)

st.set_page_config(page_title="Aplikasi Medis Kriptografi", layout="wide")

def load_css(file_name: str):
    with open(file_name) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css("style.css")

BASE_DIR = Path.cwd()
DATA_DIR = BASE_DIR / "data_pasien"
os.makedirs(DATA_DIR, exist_ok=True)

if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False
if "user_id" not in st.session_state:
    st.session_state["user_id"] = None
if "username" not in st.session_state:
    st.session_state["username"] = None

st.sidebar.markdown("### Pilih Halaman")

pages = {
    "Home": "home",
    "Catatan Diagnosa Pasien": "diagnosa",
    "Dokumen File Pasien": "file",
    "Dokumen Gambar Pasien": "image",
    "History Data Pasien": "history"
}

for label in pages.keys():
    if st.sidebar.button(label):
        st.session_state["page"] = label

if "page" not in st.session_state:
    st.session_state["page"] = "Home"

page = st.session_state["page"]

st.sidebar.write("")
if st.session_state["logged_in"]:
    st.sidebar.markdown(f"**Pengguna:** {st.session_state['username']}")
    if st.sidebar.button("Logout"):
        st.session_state["logged_in"] = False
        st.session_state["user_id"] = None
        st.session_state["username"] = None
        st.rerun()

def page_home():
    st.markdown(
    """
    # Medis Kriptografi  
    ## Aplikasi Pengaman Data Pasien 
    """
    )

    if not st.session_state["logged_in"]:
        tab1, tab2 = st.tabs(["Sign Up", "Login"])
        with tab1:
            st.markdown("### Buat akun baru")
            new_user = st.text_input("Username", key="su_username")
            new_pass = st.text_input("Password", type="password", key="su_password")
            role = st.selectbox("Peran", ["Petugas Medis", "Administrasi"], key="su_role")
            if st.button("Sign Up"):
                if not new_user or not new_pass:
                    st.error("Username dan password harus diisi.")
                else:
                    ok, err = create_user(new_user, new_pass, role)
                    if ok:
                        st.success("Akun berhasil dibuat. Silakan login.")
                    else:
                        st.error(f"Gagal membuat akun: {err}")

        with tab2:
            st.markdown("### Masuk akun Anda")
            username = st.text_input("Username", key="li_username")
            password = st.text_input("Password", type="password", key="li_password")
            if st.button("Login"):
                ok, uid, role = authenticate_user(username, password)
                if ok:
                    st.session_state["logged_in"] = True
                    st.session_state["user_id"] = uid
                    st.session_state["username"] = username
                    st.success("Login berhasil — silakan tambahkan data pasien.")
                    st.rerun()
                else:
                    st.error("Login gagal — cek username / password.")
    else:
        st.markdown("### Tambah Pasien Baru")

        nama = st.text_input("Nama Pasien")
        nik = st.text_input("NIK")
        tgl = st.date_input("Tanggal Lahir", min_value=datetime.date(1925, 1, 1), max_value=datetime.date.today())
        alamat = st.text_area("Alamat")
        nohp = st.text_input("Nomor HP")
        if st.button("Tambah Pasien"):
            if not nama:
                st.error("Nama pasien harus diisi.")
            else:
                pid = add_pasien(nama, nik, tgl.isoformat(), alamat, nohp)
                if pid:
                    st.success("Pasien berhasil ditambahkan.")
                else:
                    st.error("Gagal menambah pasien.")

def page_diagnosa():
    require_login()

    st.title("Catatan Diagnosa Pasien")
    encrypt_tab, decrypt_tab = st.tabs(["Enkripsi", "Dekripsi"])

    with encrypt_tab:
        st.markdown("#### Enkripsi Teks (Super: Caesar + Affine + AES-256-CBC)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_teks_enc")

        text_plain = st.text_area("Catatan Diagnosa Pasien")
        caesar_key = st.number_input("Kunci Caesar", min_value=1, value=3, key="enc_caesar")
        a_key = st.number_input("Kunci Affine (a)", min_value=1, value=5, key="enc_affine_a")
        b_key = st.number_input("Kunci Affine (b)", min_value=0, value=8, key="enc_affine_b")
        passphrase = st.text_input("Passphrase AES", type="password", key="enc_passphrase_aes")

        if st.button("Enkripsi Teks"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif not text_plain:
                st.error("Teks kosong.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                try:
                    cipher_text = kriptografi.super_encrypt(text_plain, passphrase, caesar_key, a_key, b_key)
                    st.success("Teks berhasil dienkripsi:")
                    #st.text_area("Hasil Enkripsi:", cipher_text, height=200)
                    st.markdown(f"""
                    <textarea readonly rows="12" style="width: 100%; padding: 10px; font-size: 14px;">
                    {cipher_text}
                    </textarea>
                    """, unsafe_allow_html=True)

                    insert_history(
                        user_id=st.session_state["user_id"],
                        pasien_id=pasien_choice,
                        jenis_data="text",
                        aksi="encrypt",
                        metode="super_caesar_affine_aes",
                        path_input=None,
                        path_output=None,
                        input_text=text_plain,
                        output_text=cipher_text
                    )
                except Exception as e:
                    st.error(f"Gagal enkripsi: {e}")

    with decrypt_tab:
        st.markdown("#### Dekripsi Teks (Super: Caesar + Affine + AES-256-CBC)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_teks_dec")

        cipher_text = st.text_area("Catatan Tersembunyi Diagnosa Pasien (Base 64)")
        caesar_key = st.number_input("Kunci Caesar", min_value=1, value=3, key="dec_caesar")
        a_key = st.number_input("Kunci Affine (a)", min_value=1, value=5, key="dec_a")
        b_key = st.number_input("Kunci Affine (b)", min_value=0, value=8, key="dec_b")
        passphrase = st.text_input("Passphrase AES", type="password", key="dec_pass")

        if st.button("Dekripsi Teks"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif not cipher_text:
                st.error("Teks terenkripsi belum diisi.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                try:
                    plain_text = kriptografi.super_decrypt(cipher_text, passphrase, caesar_key, a_key, b_key)
                    st.success("Hasil dekripsi:")
                    st.code(plain_text)

                    insert_history(
                        user_id=st.session_state["user_id"],
                        pasien_id=pasien_choice,
                        jenis_data="text",
                        aksi="decrypt",
                        metode="super_caesar_affine_aes",
                        path_input=None,
                        path_output=None,
                        input_text=cipher_text,
                        output_text=plain_text
                    )
                except Exception as e:
                    st.error(f"Gagal dekripsi: {e}")

def page_file():
    require_login()

    st.title("Dokumen File Pasien")
    enc_tab, dec_tab = st.tabs(["Enkripsi", "Dekripsi"])

    with enc_tab:
        st.markdown("#### Enkripsi File (Blowfish)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_file_enc")

        uploaded = st.file_uploader("Upload File", type=None, key="file_enc")
        passphrase = st.text_input("Passphrase Blowfish", type="password", key="bf_enc_key")
        if st.button("Enkripsi File"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif uploaded is None:
                st.error("Upload file terlebih dahulu.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "file" / "asli" / uploaded.name
                with open(in_path, "wb") as f:
                    f.write(uploaded.read())
                out_name = make_output_filename(uploaded.name, "encrypt")
                out_path = base / "file" / "encrypt" / out_name
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.blowfish_encrypt_file(str(in_path), str(out_path), passphrase)
                        insert_history(st.session_state["user_id"], pasien_choice, "file", "encrypt", "blowfish", str(in_path), str(out_path))
                        st.success("File berhasil dienkripsi.")
                        st.download_button("Download hasil enkripsi", data=open(out_path, "rb").read(), file_name=out_path.name)
                    except Exception as e:
                        st.error(f"Gagal enkripsi file: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

    with dec_tab:
        st.markdown("#### Dekripsi File (Blowfish)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_file_dec")

        uploaded_d = st.file_uploader("Upload File", type=None, key="file_dec")
        passphrase_d = st.text_input("Passphrase Blowfish", type="password", key="bf_dec_key")
        if st.button("Dekripsi File"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif uploaded_d is None:
                st.error("Upload file terenkripsi terlebih dahulu.")
            elif not passphrase_d:
                st.error("Passphrase harus diisi.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "file" / "asli" / uploaded_d.name
                with open(in_path, "wb") as f:
                    f.write(uploaded_d.read())
                out_name = make_output_filename(uploaded_d.name, "decrypt")
                out_path = base / "file" / "decrypt" / out_name
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.blowfish_decrypt_file(str(in_path), str(out_path), passphrase_d)
                        insert_history(st.session_state["user_id"], pasien_choice, "file", "decrypt", "blowfish", str(in_path), str(out_path))
                        st.success("File berhasil didekripsi.")
                        st.download_button("Download hasil dekripsi", data=open(out_path, "rb").read(), file_name=out_path.name)
                    except Exception as e:
                        st.error(f"Gagal dekripsi file: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

def page_image():
    require_login()

    st.title("Dokumen Gambar Pasien")
    enc_tab, dec_tab = st.tabs(["Embed Pesan", "Extract Pesan"])

    with enc_tab:
        st.markdown("#### Embed Pesan Ke Gambar (LSB + RC4)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_image_enc")

        image_u = st.file_uploader("Upload Gambar (PNG/JPG/JPEG)", type=["png", "jpg", "jpeg"], key="img_enc")
        secret_msg = st.text_area("Pesan Yang Disembunyikan")
        rc4_pass = st.text_input("Passphrase RC4", type="password", key="rc4_enc_key")
        if st.button("Embed"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif image_u is None:
                st.error("Upload gambar.")
            elif not secret_msg:
                st.error("Masukkan pesan.")
            elif not rc4_pass:
                st.error("Masukkan passphrase RC4.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "image" / "asli" / image_u.name
                with open(in_path, "wb") as f:
                    f.write(image_u.read())
            
                out_name = make_output_filename(image_u.name, "encrypt")
                
                out_path = base / "image" / "encrypt" / (Path(out_name).stem + ".png")
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.stego_encode_image(str(in_path), str(out_path), secret_msg.encode(), rc4_pass)
                        
                        orig_ext = Path(image_u.name).suffix
                        actual_out = str(out_path).replace(".png", orig_ext)
                        insert_history(st.session_state["user_id"], pasien_choice, "image", "encrypt", "lsb_rc4", str(in_path), actual_out)
                        st.success("Pesan berhasil disembunyikan ke gambar.")
                        
                        with open(actual_out, "rb") as f:
                            img_bytes = f.read()
                        st.image(img_bytes, caption="Gambar hasil (embed)", use_container_width=True)
                        st.download_button("Download gambar hasil", data=img_bytes, file_name=os.path.basename(actual_out))
                    except Exception as e:
                        st.error(f"Gagal embed pesan: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

    with dec_tab:
        st.markdown("#### Extract Pesan Dari Gambar (LSB + RC4)")

        pasien_rows = list_pasien(limit=200)
        pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
        pasien_choice = st.selectbox("Pilih Pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "Pilih Pasien"), key="pasien_image_dec")

        image_d = st.file_uploader("Upload Gambar Hasil Embed", type=["png", "jpg", "jpeg"], key="img_dec")
        rc4_pass_d = st.text_input("Passphrase RC4", type="password", key="rc4_dec_key")
        if st.button("Extract"):
            if not pasien_choice:
                st.error("Pilih pasien terlebih dahulu.")
            elif image_d is None:
                st.error("Upload gambar hasil embed.")
            elif not rc4_pass_d:
                st.error("Masukkan passphrase RC4.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "image" / "asli" / image_d.name
                with open(in_path, "wb") as f:
                    f.write(image_d.read())
                if KRYPTO_AVAILABLE:
                    try:
                        msg_bytes = kriptografi.stego_decode_image(str(in_path), rc4_pass_d)
                        insert_history(st.session_state["user_id"], pasien_choice, "image", "decrypt", "lsb_rc4", str(in_path), None)
                        st.success("Pesan berhasil diambil:")
                        try:
                            st.code(msg_bytes.decode())
                        except:
                            st.write(msg_bytes)
                    except Exception as e:
                        st.error(f"Gagal mengambil pesan: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

def page_history():
    require_login()
    st.title("History Data Pasien")

    nik_search = st.text_input("Masukkan NIK Pasien")

    if nik_search:
        pasien_rows = list_pasien(limit=500)
        pasien_ditemukan = None
        for p in pasien_rows:
            if p["nik"] == nik_search:
                pasien_ditemukan = p
                break

        if pasien_ditemukan:
            st.success(f"Pasien ditemukan: {pasien_ditemukan['nama']} (ID: {pasien_ditemukan['pasien_id']})")

            hist = get_history(limit=500)

            filtered_hist = [h for h in hist if h["pasien_nama"] == pasien_ditemukan["nama"]]

            if filtered_hist:
                import pandas as pd
                df_rows = []
                for h in filtered_hist:
                    df_rows.append({
                        "Waktu": h["timestamp"],
                        "User": h["username"],
                        "Jenis Data": h["jenis_data"],
                        "Aksi": h["aksi"],
                        "Metode": h["metode"],
                        "Input Text": h.get("input_text", ""),
                        "Output Text": h.get("output_text", ""),
                        "Output File": h["path_output"],
                        "Keterangan": h.get("keterangan", "")
                    })

                df = pd.DataFrame(df_rows)
                st.dataframe(df)

                csv = df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="Download Riwayat Pasien (CSV)",
                    data=csv,
                    file_name=f"history_{pasien_ditemukan['nama']}.csv",
                    mime="text/csv"
                )

            else:
                st.info("Belum ada aktivitas untuk pasien ini.")
        else:
            st.warning("Pasien dengan NIK tersebut tidak ditemukan.")
    else:
        st.info("Masukkan NIK pasien untuk melihat riwayat aktivitas.")

if page == "Home":
    page_home()
elif page == "Catatan Diagnosa Pasien":
    page_diagnosa()
elif page == "Dokumen File Pasien":
    page_file()
elif page == "Dokumen Gambar Pasien":
    page_image()
elif page == "History Data Pasien":
    page_history()

if not KRYPTO_AVAILABLE:
    st.sidebar.error("kriptografi.py belum tersedia atau tidak lengkap.")
    st.sidebar.write("Pastikan file `kriptografi.py` berada di folder project dan menyediakan fungsi yang kita sepakati.")
    st.sidebar.write(f"Import error detail: `{_IMPORT_ERROR_STR}`")

import os
import mysql.connector
import streamlit as st
from datetime import datetime
from pathlib import Path
from typing import Optional
import bcrypt

from database import (
    get_conn,
    create_user,
    authenticate_user,
    add_pasien,
    list_pasien,
    get_pasien,
    insert_history,
    get_history,
    ensure_patient_folders,
    make_output_filename,
)

try:
    import kriptografi
    KRYPTO_AVAILABLE = True
except Exception as e:
    KRYPTO_AVAILABLE = False
    _IMPORT_ERROR_STR = str(e)

st.set_page_config(page_title="Sistem Kriptografi Medis", layout="wide")

BASE_DIR = Path.cwd()
DATA_DIR = BASE_DIR / "data_pasien"
os.makedirs(DATA_DIR, exist_ok=True)

if "logged_in" not in st.session_state:
    st.session_state["logged_in"] = False
if "user_id" not in st.session_state:
    st.session_state["user_id"] = None
if "username" not in st.session_state:
    st.session_state["username"] = None

page = st.sidebar.selectbox(
    "Pilih Halaman",
    [
        "Home : Masukkan Data Pasien",
        "Catatan Diagnosa Pasien",
        "Masukkan Dokumen File Pasien",
        "Masukkan Dokumen Gambar",
        "History Data Pasien"
    ]
)

st.sidebar.write("")
if st.session_state["logged_in"]:
    st.sidebar.markdown(f"**User:** {st.session_state['username']}")
    if st.sidebar.button("Logout"):
        st.session_state["logged_in"] = False
        st.session_state["user_id"] = None
        st.session_state["username"] = None
        st.experimental_rerun()

def page_home():
    st.title("Medis Kriptografi🩺 - Aplikasi Pengaman Data Pasien")
    st.subheader("Home : Silakan Sign Up dan Log In")

    if not st.session_state["logged_in"]:
        tab1, tab2 = st.tabs(["Sign Up", "Login"])
        with tab1:
            st.markdown("### Buat akun baru")
            new_user = st.text_input("Username", key="su_username")
            new_pass = st.text_input("Password", type="password", key="su_password")
            role = st.selectbox("Role", ["petugas", "admin"], key="su_role")
            if st.button("Sign Up"):
                if not new_user or not new_pass:
                    st.error("Username dan password harus diisi.")
                else:
                    ok, err = create_user(new_user, new_pass, role)
                    if ok:
                        st.success("Akun berhasil dibuat. Silakan login.")
                    else:
                        st.error(f"Gagal membuat akun: {err}")

        with tab2:
            st.markdown("### Login")
            username = st.text_input("Username", key="li_username")
            password = st.text_input("Password", type="password", key="li_password")
            if st.button("Login"):
                ok, uid, role = authenticate_user(username, password)
                if ok:
                    st.session_state["logged_in"] = True
                    st.session_state["user_id"] = uid
                    st.session_state["username"] = username
                    st.success("Login berhasil — silakan tambahkan data pasien.")
                    st.rerun()
                else:
                    st.error("Login gagal — cek username / password.")
    else:
        st.markdown("### Tambah Pasien Baru")

        nama = st.text_input("Nama pasien (baru)")
        nik = st.text_input("NIK")
        tgl = st.date_input("Tanggal lahir")
        alamat = st.text_area("Alamat")
        nohp = st.text_input("No HP")
        if st.button("Tambah pasien"):
            if not nama:
                st.error("Nama pasien harus diisi.")
            else:
                pid = add_pasien(nama, nik, tgl.isoformat(), alamat, nohp)
                if pid:
                    st.success(f"Pasien berhasil ditambahkan (id={pid}).")
                else:
                    st.error("Gagal menambah pasien.")

def page_diagnosa():
    if not st.session_state["logged_in"]:
        st.warning("Silakan login dulu di halaman Home.")
        return
    st.title("Catatan Diagnosa Pasien")
    encrypt_tab, decrypt_tab = st.tabs(["Enkripsi", "Dekripsi"])

    pasien_rows = list_pasien(limit=200)
    pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
    pasien_choice = st.selectbox("Pilih pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "— Pilih pasien —"))

    # ENKRIPSI teks
    with encrypt_tab:
        st.markdown("#### Enkripsi Teks (Super: Caesar + Affine + AES-256-CBC)")
        text_plain = st.text_area("Masukkan teks diagnosa")
        caesar_key = st.number_input("Kunci Caesar (angka shift)", min_value=1, max_value=25, value=3)
        a_key = st.number_input("Kunci Affine (a)", min_value=1, max_value=25, value=5)
        b_key = st.number_input("Kunci Affine (b)", min_value=0, max_value=25, value=8)
        passphrase = st.text_input("Passphrase AES", type="password")
        keterangan = st.text_area("Catatan (opsional)")

        if st.button("Enkripsi Teks"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif not text_plain:
                st.error("Teks kosong.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                try:
                    cipher_text = kriptografi.super_encrypt(text_plain, passphrase, caesar_key, a_key, b_key)
                    st.success("Teks berhasil dienkripsi:")
                    st.code(cipher_text)

                    insert_history(
                        user_id=st.session_state["user_id"],
                        pasien_id=pasien_choice,
                        jenis_data="text",
                        aksi="encrypt",
                        metode="super_caesar_affine_aes",
                        path_input=None,
                        path_output=None,
                        input_text=text_plain,
                        output_text=cipher_text,
                        keterangan=keterangan
                    )
                except Exception as e:
                    st.error(f"Gagal enkripsi: {e}")

    with decrypt_tab:
        st.markdown("#### Dekripsi Teks (Super)")
        cipher_text = st.text_area("Masukkan teks terenkripsi (base64)")
        caesar_key = st.number_input("Kunci Caesar (shift)", min_value=1, max_value=25, value=3, key="dec_caesar")
        a_key = st.number_input("Kunci Affine (a)", min_value=1, max_value=25, value=5, key="dec_a")
        b_key = st.number_input("Kunci Affine (b)", min_value=0, max_value=25, value=8, key="dec_b")
        passphrase = st.text_input("Passphrase AES", type="password", key="dec_pass")

        if st.button("Dekripsi Teks"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif not cipher_text:
                st.error("Teks terenkripsi belum diisi.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                try:
                    plain_text = kriptografi.super_decrypt(cipher_text, passphrase, caesar_key, a_key, b_key)
                    st.success("Hasil dekripsi:")
                    st.code(plain_text)

                    insert_history(
                        user_id=st.session_state["user_id"],
                        pasien_id=pasien_choice,
                        jenis_data="text",
                        aksi="decrypt",
                        metode="super_caesar_affine_aes",
                        path_input=None,
                        path_output=None,
                        input_text=cipher_text,
                        output_text=plain_text,
                        keterangan=keterangan
                    )
                except Exception as e:
                    st.error(f"Gagal dekripsi: {e}")

def page_file():
    if not st.session_state["logged_in"]:
        st.warning("Silakan login dulu di halaman Home.")
        return
    st.title("Masukkan Dokumen File Pasien")
    enc_tab, dec_tab = st.tabs(["Enkripsi", "Dekripsi"])

    pasien_rows = list_pasien(limit=200)
    pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
    pasien_choice = st.selectbox("Pilih pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "— Pilih pasien —"))

    with enc_tab:
        st.markdown("#### Enkripsi File (Blowfish)")
        uploaded = st.file_uploader("Upload file untuk dienkripsi", type=None, key="file_enc")
        passphrase = st.text_input("Passphrase Blowfish", type="password", key="bf_enc_key")
        keterangan = st.text_area("Catatan (opsional)", key="file_enc_note")
        if st.button("Enkripsi File"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif uploaded is None:
                st.error("Upload file terlebih dahulu.")
            elif not passphrase:
                st.error("Passphrase harus diisi.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "file" / "asli" / uploaded.name
                with open(in_path, "wb") as f:
                    f.write(uploaded.read())
                out_name = make_output_filename(uploaded.name, "encrypt")
                out_path = base / "file" / "encrypt" / out_name
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.blowfish_encrypt_file(str(in_path), str(out_path), passphrase)
                        insert_history(st.session_state["user_id"], pasien_choice, "file", "encrypt", "blowfish", str(in_path), str(out_path), keterangan)
                        st.success("File berhasil dienkripsi.")
                        st.download_button("Download hasil enkripsi", data=open(out_path, "rb").read(), file_name=out_path.name)
                    except Exception as e:
                        st.error(f"Gagal enkripsi file: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

    with dec_tab:
        st.markdown("#### Dekripsi File (Blowfish)")
        uploaded_d = st.file_uploader("Upload file terenkripsi untuk didekripsi", type=None, key="file_dec")
        passphrase_d = st.text_input("Passphrase Blowfish untuk dekripsi", type="password", key="bf_dec_key")
        if st.button("Dekripsi File"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif uploaded_d is None:
                st.error("Upload file terenkripsi dulu.")
            elif not passphrase_d:
                st.error("Passphrase harus diisi.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "file" / "asli" / uploaded_d.name
                with open(in_path, "wb") as f:
                    f.write(uploaded_d.read())
                out_name = make_output_filename(uploaded_d.name, "decrypt")
                out_path = base / "file" / "decrypt" / out_name
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.blowfish_decrypt_file(str(in_path), str(out_path), passphrase_d)
                        insert_history(st.session_state["user_id"], pasien_choice, "file", "decrypt", "blowfish", str(in_path), str(out_path))
                        st.success("File berhasil didekripsi.")
                        st.download_button("Download hasil dekripsi", data=open(out_path, "rb").read(), file_name=out_path.name)
                    except Exception as e:
                        st.error(f"Gagal dekripsi file: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

def page_image():
    if not st.session_state["logged_in"]:
        st.warning("Silakan login dulu di halaman Home.")
        return
    st.title("Masukkan Dokumen Gambar")
    enc_tab, dec_tab = st.tabs(["Enkripsi (embed pesan)", "Dekripsi (ambil pesan)"])

    pasien_rows = list_pasien(limit=200)
    pasien_map = {r["pasien_id"]: f"{r['nama']} — {r['nik'] or ''}" for r in pasien_rows}
    pasien_choice = st.selectbox("Pilih pasien", options=[None] + list(pasien_map.keys()), format_func=lambda x: pasien_map.get(x, "— Pilih pasien —"))

    with enc_tab:
        st.markdown("#### Embed pesan ke gambar (LSB + RC4)")
        image_u = st.file_uploader("Upload gambar (PNG/JPG/JPEG recommended)", type=["png", "jpg", "jpeg"], key="img_enc")
        secret_msg = st.text_area("Pesan yang akan disembunyikan (plaintext)")
        rc4_pass = st.text_input("Passphrase RC4 (untuk cipher pesan)", type="password", key="rc4_enc_key")
        keterangan = st.text_area("Catatan (opsional)", key="img_enc_note")
        if st.button("Embed ke gambar"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif image_u is None:
                st.error("Upload gambar.")
            elif not secret_msg:
                st.error("Masukkan pesan.")
            elif not rc4_pass:
                st.error("Masukkan passphrase RC4.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "image" / "asli" / image_u.name
                with open(in_path, "wb") as f:
                    f.write(image_u.read())
                # prepare out_path placeholder ending with .png (kriptografi will replace to actual ext)
                out_name = make_output_filename(image_u.name, "encrypt")
                # ensure placeholder ends with .png so internal replace works
                out_path = base / "image" / "encrypt" / (Path(out_name).stem + ".png")
                if KRYPTO_AVAILABLE:
                    try:
                        kriptografi.stego_encode_image(str(in_path), str(out_path), secret_msg.encode(), rc4_pass)
                        # kriptografi saves using original extension; compute actual saved path:
                        orig_ext = Path(image_u.name).suffix
                        actual_out = str(out_path).replace(".png", orig_ext)
                        insert_history(st.session_state["user_id"], pasien_choice, "image", "encrypt", "lsb_rc4", str(in_path), actual_out, keterangan)
                        st.success("Pesan berhasil disembunyikan ke gambar.")
                        # show result and download
                        with open(actual_out, "rb") as f:
                            img_bytes = f.read()
                        st.image(img_bytes, caption="Gambar hasil (embed)", use_column_width=True)
                        st.download_button("Download gambar hasil", data=img_bytes, file_name=os.path.basename(actual_out))
                    except Exception as e:
                        st.error(f"Gagal embed pesan: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

    with dec_tab:
        st.markdown("#### Ambil pesan dari gambar")
        image_d = st.file_uploader("Upload gambar hasil embed", type=["png", "jpg", "jpeg"], key="img_dec")
        rc4_pass_d = st.text_input("Passphrase RC4 untuk dekripsi pesan", type="password", key="rc4_dec_key")
        if st.button("Ambil pesan"):
            if not pasien_choice:
                st.error("Pilih pasien dulu.")
            elif image_d is None:
                st.error("Upload gambar hasil embed.")
            elif not rc4_pass_d:
                st.error("Masukkan passphrase RC4.")
            else:
                base = ensure_patient_folders(pasien_choice)
                in_path = base / "image" / "asli" / image_d.name
                with open(in_path, "wb") as f:
                    f.write(image_d.read())
                if KRYPTO_AVAILABLE:
                    try:
                        msg_bytes = kriptografi.stego_decode_image(str(in_path), rc4_pass_d)
                        insert_history(st.session_state["user_id"], pasien_choice, "image", "decrypt", "lsb_rc4", str(in_path), None)
                        st.success("Pesan berhasil diambil:")
                        try:
                            st.code(msg_bytes.decode())
                        except:
                            st.write(msg_bytes)
                    except Exception as e:
                        st.error(f"Gagal mengambil pesan: {e}")
                else:
                    st.error("kriptografi.py tidak tersedia.")

def page_history():
    st.title("History Data Pasien")
    col1, col2 = st.columns((1, 2))

    with col1:
        st.markdown("### Daftar Pasien (10 teratas)")
        nik_q = st.text_input("Cari pasien per NIK")
        rows = list_pasien(limit=10, nik_search=nik_q if nik_q else None)
        for r in rows:
            st.write(f"ID: {r['pasien_id']} — **{r['nama']}** — NIK: {r['nik'] or '-'}")

    with col2:
        st.markdown("### Log Aktivitas (terbaru)")
        hist = get_history(limit=200)
        if hist:
            import pandas as pd
            df_rows = []
            for h in hist:
                df_rows.append({
                    "waktu": h["timestamp"],
                    "user": h["username"],
                    "pasien": h["pasien_nama"],
                    "jenis": h["jenis_data"],
                    "aksi": h["aksi"],
                    "metode": h["metode"],
                    "path_output": h["path_output"]
                })
            st.dataframe(pd.DataFrame(df_rows))
        else:
            st.info("Belum ada history aktivitas.")

if page == "Home : Masukkan Data Pasien":
    page_home()
elif page == "Catatan Diagnosa Pasien":
    page_diagnosa()
elif page == "Masukkan Dokumen File Pasien":
    page_file()
elif page == "Masukkan Dokumen Gambar":
    page_image()
elif page == "History Data Pasien":
    page_history()

if not KRYPTO_AVAILABLE:
    st.sidebar.error("kriptografi.py belum tersedia atau tidak lengkap.")
    st.sidebar.write("Pastikan file `kriptografi.py` berada di folder project dan menyediakan fungsi yang kita sepakati.")
    st.sidebar.write(f"Import error detail: `{_IMPORT_ERROR_STR}`")

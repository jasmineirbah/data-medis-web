import os
from pathlib import Path
import mysql.connector
import bcrypt
import streamlit as st
from typing import Optional

DATA_DIR = Path("data_pasien")
DATA_DIR.mkdir(exist_ok=True)

def get_conn():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="medis_kriptografi"
    )

def hash_password(password: str) -> bytes:
    """Membuat hash password aman"""
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt())

def check_password(password: str, hashed: bytes) -> bool:
    """Verifikasi password dengan hash"""
    return bcrypt.checkpw(password.encode(), hashed)

def create_user(username: str, password: str, role: str = "petugas"):
    conn = get_conn()
    cur = conn.cursor()
    pw_hash = hash_password(password)
    try:
        cur.execute("""
            INSERT INTO users (username, password, role)
            VALUES (%s, %s, %s)
        """, (username, pw_hash, role))
        conn.commit()
        return True, None
    except mysql.connector.Error as e:
        return False, str(e)
    finally:
        conn.close()

def authenticate_user(username: str, password: str):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM users WHERE username = %s", (username,))
    row = cur.fetchone()
    conn.close()
    if row:
        stored_pw = row["password"]
        if isinstance(stored_pw, str):
            stored_pw = stored_pw.encode()
        if check_password(password, stored_pw):
            return True, row["user_id"], row["role"]
    return False, None, None

def add_pasien(nama, nik=None, tgl_lahir=None, alamat=None, no_hp=None):
    conn = get_conn()
    c = conn.cursor()
    try:
        c.execute("""
        INSERT INTO data_pasien (nama, nik, tgl_lahir, alamat, no_hp)
        VALUES (%s, %s, %s, %s, %s)
        """, (nama, nik, tgl_lahir, alamat, no_hp))
        conn.commit()
        return c.lastrowid
    except Exception as e:
        st.error(f"Gagal insert pasien: {e}")
        return None
    finally:
        conn.close()

def list_pasien(limit=100, nik_search: Optional[str] = None):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    if nik_search:
        cur.execute("""
            SELECT * FROM data_pasien 
            WHERE nik LIKE %s 
            ORDER BY pasien_id DESC 
            LIMIT %s
        """, (f"%{nik_search}%", limit))
    else:
        cur.execute("SELECT * FROM data_pasien ORDER BY pasien_id DESC LIMIT %s", (limit,))
    rows = cur.fetchall()
    conn.close()
    return rows

def get_pasien(pasien_id):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM data_pasien WHERE pasien_id = %s", (pasien_id,))
    r = cur.fetchone()
    conn.close()
    return r

def insert_history(user_id, pasien_id, jenis_data, aksi, metode,
                   path_input=None, path_output=None,
                   input_text=None, output_text=None, keterangan=None):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO history_kriptografi
        (user_id, pasien_id, jenis_data, aksi, metode,
         path_input, path_output, input_text, output_text, keterangan, timestamp)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
    """, (user_id, pasien_id, jenis_data, aksi, metode,
          path_input, path_output, input_text, output_text, keterangan))
    conn.commit()
    conn.close()

def get_history(limit=200):
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT h.*, u.username, p.nama AS pasien_nama, p.nik AS pasien_nik
        FROM history_kriptografi h
        LEFT JOIN users u ON h.user_id = u.user_id
        LEFT JOIN data_pasien p ON h.pasien_id = p.pasien_id
        ORDER BY h.timestamp DESC
        LIMIT %s
    """, (limit,))
    rows = cur.fetchall()
    conn.close()
    return rows

def ensure_patient_folders(pasien_id: int):
    base = DATA_DIR / f"pasien_{pasien_id}"
    for kind in ("text", "file", "image"):
        for state in ("asli", "encrypt", "decrypt"):
            p = base / kind / state
            p.mkdir(parents=True, exist_ok=True)
    return base

def make_output_filename(original_name: str, aksi: str):
    name, ext = os.path.splitext(original_name)
    suffix = "_encrypted" if aksi == "encrypt" else "_decrypted"
    return f"{name}{suffix}{ext}"

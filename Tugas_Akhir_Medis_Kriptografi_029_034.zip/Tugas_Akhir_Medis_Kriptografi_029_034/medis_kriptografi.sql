-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 04:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medis_kriptografi`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_pasien`
--

CREATE TABLE `data_pasien` (
  `pasien_id` int(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `nik` varchar(20) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_pasien`
--

INSERT INTO `data_pasien` (`pasien_id`, `nama`, `nik`, `tgl_lahir`, `alamat`, `no_hp`, `created_at`) VALUES
(1, 'fifi', '', '2025-11-07', 'kakakakak', '098655', '2025-11-07 19:46:15');

-- --------------------------------------------------------

--
-- Table structure for table `history_kriptografi`
--

CREATE TABLE `history_kriptografi` (
  `history_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `pasien_id` int(11) DEFAULT NULL,
  `jenis_data` varchar(20) DEFAULT NULL,
  `aksi` varchar(20) DEFAULT NULL,
  `metode` varchar(50) DEFAULT NULL,
  `path_input` varchar(255) DEFAULT NULL,
  `path_output` varchar(255) DEFAULT NULL,
  `input_text` text NOT NULL,
  `output_text` text NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history_kriptografi`
--

INSERT INTO `history_kriptografi` (`history_id`, `user_id`, `pasien_id`, `jenis_data`, `aksi`, `metode`, `path_input`, `path_output`, `input_text`, `output_text`, `timestamp`, `keterangan`) VALUES
(1, 1, 1, 'text', 'encrypt', 'super_caesar_affine_aes', NULL, NULL, 'jajjajaja', '0WO8ido495mZEYXnoHrxdxy/Wrar8Lx+0/eVHOJ5KXw=', '2025-11-07 19:52:18', ''),
(2, 1, 1, 'text', 'decrypt', 'super_caesar_affine_aes', NULL, NULL, '0WO8ido495mZEYXnoHrxdxy/Wrar8Lx+0/eVHOJ5KXw=', 'jajjajaja', '2025-11-07 19:54:13', ''),
(3, 1, 1, 'text', 'encrypt', 'super_caesar_affine_aes', NULL, NULL, 'lalalal', 'WyXvi/plmuTR3xKF6zcFXoCfmADg3U01yxJHmhG7Eac=', '2025-11-07 20:28:09', ''),
(4, 1, 1, 'text', 'encrypt', 'super_caesar_affine_aes', NULL, NULL, 'kaakkaka', '8q6+ek3IMhSwI8TeHU95P+Q9uAhlmZG8gYDzOF61SZ8=', '2025-11-07 20:31:27', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'admin',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `role`, `created_at`) VALUES
(1, 'lalalal', '$2b$12$1JZQl7ftPbyw4s9AQIOd/O.yAPVOMzIwwjW4hyb8ktzvZ5b3JDKbm', 'petugas', '2025-11-07 19:43:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_pasien`
--
ALTER TABLE `data_pasien`
  ADD PRIMARY KEY (`pasien_id`),
  ADD UNIQUE KEY `nik` (`nik`);

--
-- Indexes for table `history_kriptografi`
--
ALTER TABLE `history_kriptografi`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `pasien_id` (`pasien_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_pasien`
--
ALTER TABLE `data_pasien`
  MODIFY `pasien_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `history_kriptografi`
--
ALTER TABLE `history_kriptografi`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history_kriptografi`
--
ALTER TABLE `history_kriptografi`
  ADD CONSTRAINT `history_kriptografi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `history_kriptografi_ibfk_2` FOREIGN KEY (`pasien_id`) REFERENCES `data_pasien` (`pasien_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
